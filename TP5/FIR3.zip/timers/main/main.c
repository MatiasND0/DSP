#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"
#include "driver/gptimer.h"
#include "esp_log.h"
#include "esp_adc/adc_oneshot.h"
#include "driver/dac_oneshot.h"
#include "math.h"

#define GPIO_PIN 14
#define BUFF_SIZE 50

static const char *TAG = "example";

dac_oneshot_handle_t dac_handle;
adc_oneshot_unit_handle_t adc_handle;

float FIR_Coef[BUFF_SIZE] = {0.0000470,0.0000703,-0.0001902,-0.0004949,0.0001168,0.0023249,0.0051598,0.0061722,0.0038486,0.0002658,0.0006693,0.0089430,0.0224049,0.0316025,0.0274638,0.0110779,-0.0031283,0.0034659,0.0367712,0.0786862,0.0933692,0.0505265,-0.0494938,-0.1683846,-0.2488095,-0.2488095,-0.1683846,-0.0494938,0.0505265,0.0933692,0.0786862,0.0367712,0.0034659,-0.0031283,0.0110779,0.0274638,0.0316025,0.0224049,0.0089430,0.0006693,0.0002658,0.0038486,0.0061722,0.0051598,0.0023249,0.0001168,-0.0004949,-0.0001902,0.0000703,0.0000470};

typedef struct
{
    float adc_buff[BUFF_SIZE];
    int head;
    int tail;
    uint8_t dac_buff[BUFF_SIZE];
} CircularBuffer;

CircularBuffer buffStruct = {
    .head = 0,
    .tail = 0,
};

void CircularBufferLoad(CircularBuffer *buffer,  int value)
{
    for (int i = BUFF_SIZE-1; i > 0; i--)
    {
        buffer->adc_buff[i] = buffer->adc_buff[i-1];
    }
    buffer->adc_buff[0] = value;
    
    float_t aux = 0;
    for (int i = 0; i < BUFF_SIZE; i++)
        aux += (buffer->adc_buff[i])*FIR_Coef[i];

    buffer->dac_buff[buffer->head] = (aux/32+127/2);
    
    //buffer->head = (buffer->head + 1) % BUFF_SIZE;
}

void gpio_init()
{
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << GPIO_PIN),
        .mode = GPIO_MODE_OUTPUT};
    gpio_config(&io_conf);
}

uint32_t cp0_regs[18];
int state = 0;
int aux;
static bool IRAM_ATTR timer_on_alarm_cb_v2(gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_data)
{

    // enable FPU
    xthal_set_cpenable(1);
    // Save FPU registers
    xthal_save_cp0(cp0_regs);
    
    state = !state;
    gpio_set_level(GPIO_PIN, state);
    adc_oneshot_read(adc_handle, ADC_CHANNEL_7, &aux); // valor de muestreo medido 40us=>25000kHz
    CircularBufferLoad(&buffStruct,aux);
    dac_oneshot_output_voltage(dac_handle, buffStruct.dac_buff[buffStruct.head]);

    // Restore FPU
    xthal_restore_cp0(cp0_regs);
    // and turn it back off
    xthal_set_cpenable(0);
    
    return (pdTRUE);
}

void app_main(void)
{
    //--------------------------------------ADC-------------------------------------------------//
    gpio_init();

    adc_oneshot_unit_init_cfg_t init_config1 = {                                        //Configuracion del ADC
        .unit_id = ADC_UNIT_1,                                                              //Canal 1
        .clk_src = ADC_RTC_CLK_SRC_RC_FAST};                                                //Fuente del clock (200 Ksps)
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_config1, &adc_handle));      

    adc_oneshot_chan_cfg_t config = {                                                   //Configuracion del ADC
        .bitwidth = ADC_BITWIDTH_12,                                                        //Resolucion del ADC (12bits)
        .atten = ADC_ATTEN_DB_12,                                                           //Atenuacion (10 a 2450 mV)
    };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc_handle, ADC_CHANNEL_7, &config));    //Inicializo el manejador con la configuracion

    //--------------------------------------DAC-------------------------------------------------//

    // Configuro el DAC (DAC 2 | 8 Bits )
    dac_oneshot_config_t chan1_cfg = {                                                  //Configuracion del DAC
        .chan_id = DAC_CHAN_1,                                                          //Canal 1
    };
    ESP_ERROR_CHECK(dac_oneshot_new_channel(&chan1_cfg, &dac_handle));                  //Inicializo el manejador con la configuracion

    //-----------------------------------TIMER--------------------------------------------------//

    ESP_LOGI(TAG, "Create timer handle");
    gptimer_handle_t gptimer = NULL;                                                    //Manejador del Timer
    gptimer_config_t timer_config = {                                                   //Configuracion del timer
        .clk_src = GPTIMER_CLK_SRC_DEFAULT,                                                 //Fuente del clock
        .direction = GPTIMER_COUNT_UP,                                                      //Direccion de cuenta (UP)
        .resolution_hz = 10000,                                                             //Resolucion del timer (100us)
    };
    ESP_ERROR_CHECK(gptimer_new_timer(&timer_config, &gptimer));                        //Inicializo el manejador del timer con la configuracion

    gptimer_event_callbacks_t cbs = {                                                   //Configuracion de la interrupcion
        .on_alarm = timer_on_alarm_cb_v2,                                               //Funcion de interrupcion
    };
    ESP_ERROR_CHECK(gptimer_register_event_callbacks(gptimer, &cbs, NULL));             //Inicializo el manejador de la interrupcion con la configuracion    
    ESP_LOGI(TAG, "Enable timer");                              
    ESP_ERROR_CHECK(gptimer_enable(gptimer));                                           

    ESP_LOGI(TAG, "Start timer, auto-reload at alarm event");
    gptimer_alarm_config_t alarm_config2 = {
        .reload_count = 0,
        .alarm_count = 10,
        .flags.auto_reload_on_alarm = true,
    };
    
    ESP_ERROR_CHECK(gptimer_set_alarm_action(gptimer, &alarm_config2));                 //
    ESP_ERROR_CHECK(gptimer_start(gptimer));                                            //Inicializo el timer
    
}